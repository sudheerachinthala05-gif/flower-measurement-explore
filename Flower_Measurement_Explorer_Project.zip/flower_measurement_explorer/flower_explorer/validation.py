from .models import BOUNDS, MEASUREMENTS, SPECIES

def validate_measurement(field, value):
    if field not in MEASUREMENTS:
        raise ValueError("Unknown measurement field.")
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise ValueError("Enter a valid number, for example 4.7.")
    low, high = BOUNDS[field]
    if not low <= number <= high:
        raise ValueError(f"{field.replace('_', ' ')} must be between {low} and {high} cm.")
    return round(number, 2)

def validate_species(value, allow_blank=True):
    value = str(value).strip()
    if not value and allow_blank:
        return None
    match = next((s for s in SPECIES if s.lower() == value.lower()), None)
    if not match:
        raise ValueError("Species must be Setosa, Versicolor, Virginica, or blank (unclassified).")
    return match

def validate_record_data(data):
    clean = {field: validate_measurement(field, data[field]) for field in MEASUREMENTS}
    clean["species"] = validate_species(data.get("species", ""))
    clean["notes"] = str(data.get("notes", "")).strip()[:300]
    return clean
