from pathlib import Path
from datetime import datetime
from .analytics import summary
from .models import MEASUREMENTS

def export_summary(records, reports_dir="reports"):
    folder = Path(reports_dir)
    folder.mkdir(parents=True, exist_ok=True)
    data = summary(records)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    lines = [
        "# Flower Measurement Explorer — Executive Summary", "",
        f"Generated: {datetime.now().isoformat(timespec='seconds')}", "",
        f"- Total records: **{data['total']}**",
        f"- Classified: **{data['classified']}**",
        f"- Unclassified: **{data['unclassified']}**", "",
        "## Records by category", ""
    ]
    for name, count in data["species_counts"].items():
        lines.append(f"- {name}: {count}")
    lines += ["", "## Measurement statistics", "",
              "| Measurement | Count | Average (cm) | Minimum (cm) | Maximum (cm) |",
              "|---|---:|---:|---:|---:|"]
    for field, stats in data["measurements"].items():
        vals = [f"{stats[k]:.2f}" if stats[k] is not None else "—"
                for k in ("average", "minimum", "maximum")]
        lines.append(f"| {field.replace('_',' ').title()} | {stats['count']} | " +
                     " | ".join(vals) + " |")
    path = folder / f"executive_summary_{stamp}.md"
    path.write_text("\\n".join(lines), encoding="utf-8")
    audit = folder / f"audit_{stamp}.txt"
    audit.write_text("\\n".join(
        f"{r.created_at} | ID={r.record_id} | {r.species or 'Unclassified'} | " +
        ", ".join(f"{f}={getattr(r,f):.2f}" for f in MEASUREMENTS)
        for r in records), encoding="utf-8")
    return path, audit

def create_charts(records, reports_dir="reports"):
    try:
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise RuntimeError("Matplotlib is not installed. Run: pip install matplotlib") from exc
    folder = Path(reports_dir)
    folder.mkdir(parents=True, exist_ok=True)
    if not records:
        raise ValueError("No records available to plot.")
    path = folder / "flower_measurement_distributions.png"
    fig, axes = plt.subplots(2, 2, figsize=(11, 8))
    for ax, field in zip(axes.flat, MEASUREMENTS):
        groups = [[getattr(r, field) for r in records if r.species == species]
                  for species in ("Setosa", "Versicolor", "Virginica")]
        labels = ["Setosa", "Versicolor", "Virginica"]
        if any(groups):
            ax.boxplot([g for g in groups if g], labels=[l for l,g in zip(labels,groups) if g])
        else:
            ax.hist([getattr(r, field) for r in records], bins=10)
            ax.set_xlabel("All records")
        ax.set_title(field.replace("_", " ").title())
        ax.set_ylabel("Centimetres")
        ax.grid(axis="y", alpha=.25)
    fig.suptitle("Flower Measurement Explorer — Measurement Distributions")
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)
    return path
