from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Optional

SPECIES = ("Setosa", "Versicolor", "Virginica")
MEASUREMENTS = ("sepal_length", "sepal_width", "petal_length", "petal_width")
# Broad botanical input bounds in centimetres, used to reject implausible entries.
BOUNDS = {
    "sepal_length": (0.1, 20.0),
    "sepal_width": (0.1, 15.0),
    "petal_length": (0.1, 20.0),
    "petal_width": (0.1, 15.0),
}

@dataclass
class FlowerRecord:
    record_id: int
    sepal_length: float
    sepal_width: float
    petal_length: float
    petal_width: float
    species: Optional[str] = None
    notes: str = ""
    created_at: str = ""

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now().isoformat(timespec="seconds")

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, data):
        return cls(
            record_id=int(data["record_id"]),
            sepal_length=float(data["sepal_length"]),
            sepal_width=float(data["sepal_width"]),
            petal_length=float(data["petal_length"]),
            petal_width=float(data["petal_width"]),
            species=(str(data["species"]).strip().title() if data.get("species") else None),
            notes=str(data.get("notes", "")),
            created_at=str(data.get("created_at", "")),
        )
