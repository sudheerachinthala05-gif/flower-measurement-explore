import csv, json
from pathlib import Path
from .models import FlowerRecord, MEASUREMENTS

FIELDS = ["record_id", *MEASUREMENTS, "species", "notes", "created_at"]

class Storage:
    def __init__(self, data_dir="data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.json_path = self.data_dir / "flowers.json"
        self.csv_path = self.data_dir / "flowers.csv"

    def load(self):
        if not self.json_path.exists():
            self.save([])
            return []
        try:
            raw = json.loads(self.json_path.read_text(encoding="utf-8"))
            if not isinstance(raw, list):
                raise ValueError("JSON root must be a list.")
            records = [FlowerRecord.from_dict(row) for row in raw]
            return records
        except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            backup = self.json_path.with_suffix(".corrupt.json")
            try:
                self.json_path.replace(backup)
            except OSError:
                pass
            print(f"WARNING: storage file was invalid ({exc}). Starting with an empty dataset.")
            return []

    def save(self, records):
        payload = [r.to_dict() for r in records]
        temp = self.json_path.with_suffix(".tmp")
        temp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        temp.replace(self.json_path)
        with self.csv_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=FIELDS)
            writer.writeheader()
            writer.writerows(payload)

    def next_id(self, records):
        return max((r.record_id for r in records), default=0) + 1
