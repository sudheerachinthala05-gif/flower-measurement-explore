import csv
from pathlib import Path
from .models import FlowerRecord
from .validation import validate_record_data

REQUIRED = {"sepal_length", "sepal_width", "petal_length", "petal_width"}

def import_csv(path, existing_records):
    path = Path(path)
    added, errors = [], []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or not REQUIRED.issubset(set(reader.fieldnames)):
            raise ValueError("CSV must contain: " + ", ".join(sorted(REQUIRED)))
        next_id = max((r.record_id for r in existing_records), default=0) + 1
        for line_no, row in enumerate(reader, start=2):
            try:
                clean = validate_record_data(row)
                added.append(FlowerRecord(record_id=next_id, **clean))
                next_id += 1
            except (ValueError, KeyError) as exc:
                errors.append(f"Row {line_no}: {exc}")
    return added, errors
