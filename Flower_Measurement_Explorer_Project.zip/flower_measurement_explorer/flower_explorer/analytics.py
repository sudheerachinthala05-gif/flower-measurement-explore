from collections import Counter, defaultdict
from statistics import mean
from .models import MEASUREMENTS, SPECIES

def summary(records):
    result = {
        "total": len(records),
        "classified": sum(bool(r.species) for r in records),
        "unclassified": sum(not r.species for r in records),
        "species_counts": Counter(r.species or "Unclassified" for r in records),
        "measurements": {},
        "species_averages": {},
    }
    for field in MEASUREMENTS:
        values = [getattr(r, field) for r in records]
        result["measurements"][field] = {
            "count": len(values),
            "average": mean(values) if values else None,
            "minimum": min(values) if values else None,
            "maximum": max(values) if values else None,
        }
    for species in SPECIES:
        group = [r for r in records if r.species == species]
        if group:
            result["species_averages"][species] = {
                field: mean(getattr(r, field) for r in group) for field in MEASUREMENTS
            }
    return result

def search_records(records, keyword="", category="all"):
    keyword = keyword.casefold().strip()
    found = []
    for r in records:
        if category != "all" and (r.species or "Unclassified").casefold() != category.casefold():
            continue
        haystack = " ".join([str(r.record_id), r.species or "Unclassified", r.notes,
                             *(str(getattr(r, f)) for f in MEASUREMENTS)]).casefold()
        if keyword in haystack:
            found.append(r)
    return found

def nearest_species_pattern(record, records):
    """Exploratory nearest-centroid comparison; not a trained classifier."""
    centroids = {}
    for species in SPECIES:
        group = [r for r in records if r.species == species]
        if group:
            centroids[species] = [mean(getattr(r, f) for r in group) for f in MEASUREMENTS]
    if not centroids:
        return []
    vector = [getattr(record, f) for f in MEASUREMENTS]
    ranked = []
    for species, centroid in centroids.items():
        distance = sum((a-b)**2 for a, b in zip(vector, centroid)) ** 0.5
        ranked.append((species, distance))
    return sorted(ranked, key=lambda item: item[1])
