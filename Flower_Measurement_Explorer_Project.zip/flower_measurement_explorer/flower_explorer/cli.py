import os
from .models import FlowerRecord, MEASUREMENTS, SPECIES
from .validation import validate_measurement, validate_record_data, validate_species
from .storage import Storage
from .analytics import summary, search_records, nearest_species_pattern
from .exports import export_summary, create_charts
from .importer import import_csv

BANNER = r"""
  _____ _ower Measurement Explorer
 |  Find patterns. Explore measurements. Understand your data.
"""

def ask(prompt):
    return input(prompt).strip()

def ask_measurement(field):
    while True:
        raw = ask(f"  {field.replace('_',' ').title()} (cm): ")
        try:
            return validate_measurement(field, raw)
        except ValueError as exc:
            print(f"  ! {exc}")

def print_records(records):
    if not records:
        print("No matching records.")
        return
    print(f"{'ID':>4}  {'Sepal L':>7} {'Sepal W':>7} {'Petal L':>7} {'Petal W':>7}  {'Species':<12} Notes")
    print("-" * 85)
    for r in records:
        print(f"{r.record_id:>4}  {r.sepal_length:>7.2f} {r.sepal_width:>7.2f} "
              f"{r.petal_length:>7.2f} {r.petal_width:>7.2f}  "
              f"{(r.species or 'Unclassified'):<12} {r.notes[:24]}")

def add_record(records, store):
    print("\\nEnter flower measurements in centimetres. Leave species blank to keep unclassified.")
    data = {field: ask_measurement(field) for field in MEASUREMENTS}
    while True:
        raw_species = ask("  Species [Setosa / Versicolor / Virginica / blank]: ")
        try:
            data["species"] = validate_species(raw_species)
            break
        except ValueError as exc:
            print(f"  ! {exc}")
    data["notes"] = ask("  Notes (optional): ")[:300]
    record = FlowerRecord(record_id=store.next_id(records), **data)
    records.append(record)
    store.save(records)
    print(f"Saved record #{record.record_id}.")
    ranked = nearest_species_pattern(record, records)
    if not record.species and ranked:
        print("Exploratory nearest class patterns (not an automatic classification):")
        for name, distance in ranked:
            print(f"  {name:<12} distance {distance:.2f}")

def show_summary(records):
    s = summary(records)
    print("\\nEXECUTIVE SUMMARY")
    print(f"Total: {s['total']} | Classified: {s['classified']} | Unclassified: {s['unclassified']}")
    print("Category counts:")
    for name, count in s["species_counts"].items():
        print(f"  {name:<14} {count}")
    print("\\nMeasurement statistics (cm):")
    for field, values in s["measurements"].items():
        if values["count"]:
            print(f"  {field:<14} avg {values['average']:.2f} | min {values['minimum']:.2f} | max {values['maximum']:.2f}")
    print("\\nClass pattern averages (cm):")
    for species, averages in s["species_averages"].items():
        print(f"  {species:<12} " + " | ".join(f"{f[:6]} {v:.2f}" for f,v in averages.items()))

def main():
    store = Storage()
    records = store.load()
    print(BANNER)
    while True:
        print("\\nMAIN MENU")
        print("1. Add flower record")
        print("2. View all records")
        print("3. Search / filter records")
        print("4. Executive summary and class patterns")
        print("5. Generate measurement charts")
        print("6. Export summary and audit log")
        print("7. Bulk import CSV")
        print("8. Save and exit")
        choice = ask("Choose [1-8]: ")
        if choice == "1":
            add_record(records, store)
        elif choice == "2":
            print_records(records)
        elif choice == "3":
            keyword = ask("Keyword (blank = all): ")
            category = ask("Category [all / Setosa / Versicolor / Virginica / Unclassified]: ") or "all"
            if category.lower() not in ("all", "setosa", "versicolor", "virginica", "unclassified"):
                print("Unknown category; using all.")
                category = "all"
            print_records(search_records(records, keyword, category))
        elif choice == "4":
            show_summary(records)
        elif choice == "5":
            try:
                print(f"Chart saved to: {create_charts(records)}")
            except (RuntimeError, ValueError) as exc:
                print(f"Could not create chart: {exc}")
        elif choice == "6":
            md, audit = export_summary(records)
            print(f"Summary: {md}\\nAudit log: {audit}")
        elif choice == "7":
            path = ask("Path to source CSV: ")
            try:
                added, errors = import_csv(path, records)
                records.extend(added)
                store.save(records)
                print(f"Imported {len(added)} valid row(s).")
                if errors:
                    print("Rejected rows:")
                    for error in errors:
                        print("  " + error)
            except (OSError, ValueError) as exc:
                print(f"Import failed: {exc}")
        elif choice == "8":
            store.save(records)
            print("All records saved. Goodbye!")
            break
        else:
            print("Please choose a number from 1 to 8.")

if __name__ == "__main__":
    main()
