"""Flower Measurement Explorer - terminal application."""
from flower_explorer.cli import main

if __name__ == "__main__":
    main()
