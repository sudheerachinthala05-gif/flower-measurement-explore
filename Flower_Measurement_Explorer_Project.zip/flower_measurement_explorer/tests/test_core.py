import tempfile, unittest
from pathlib import Path
from flower_explorer.models import FlowerRecord
from flower_explorer.validation import validate_measurement, validate_species
from flower_explorer.analytics import summary, search_records
from flower_explorer.storage import Storage

class ExplorerTests(unittest.TestCase):
    def test_measurement_validation(self):
        self.assertEqual(validate_measurement("sepal_length", "4.56"), 4.56)
        with self.assertRaises(ValueError):
            validate_measurement("sepal_length", "abc")
        with self.assertRaises(ValueError):
            validate_measurement("sepal_length", "25")

    def test_species_validation(self):
        self.assertEqual(validate_species("setosa"), "Setosa")
        self.assertIsNone(validate_species(""))

    def test_summary_and_search(self):
        records = [FlowerRecord(1, 5.1, 3.5, 1.4, .2, "Setosa", "demo"),
                   FlowerRecord(2, 6.0, 2.7, 4.5, 1.5, None, "unknown")]
        result = summary(records)
        self.assertEqual(result["total"], 2)
        self.assertEqual(result["unclassified"], 1)
        self.assertEqual(len(search_records(records, "demo")), 1)

    def test_storage_round_trip(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Storage(tmp)
            records = [FlowerRecord(1, 5.1, 3.5, 1.4, .2, "Setosa")]
            store.save(records)
            self.assertEqual(len(store.load()), 1)

if __name__ == "__main__":
    unittest.main()
