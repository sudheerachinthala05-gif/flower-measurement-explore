# Flower Measurement Explorer
**Campus Catalyst — Project #118 | Domain: AI, APIs & Smart Applications**

A beginner-friendly Python 3.10+ terminal application for recording, exploring and visualizing flower measurements before classification.

## Features
- Menu-driven terminal interface.
- Defensive numeric and species validation.
- Local persistence in both `data/flowers.json` and `data/flowers.csv`.
- Keyword search and species/category filters.
- Executive summary: totals, averages, minima, maxima and class counts.
- Exploratory class-pattern comparison using nearest class centroids. This is an aid to exploration, **not a trained classifier**.
- Matplotlib measurement distribution charts.
- Markdown executive summary and plain-text audit log export.
- Bulk CSV import with row-by-row validation errors.
- Corrupt JSON recovery (renames the damaged file to `.corrupt.json`).

## Requirements
- Python 3.10 or newer.
- Matplotlib (optional; required only for chart generation).

## Run
```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
python main.py
```
The application creates `data/` and `reports/` automatically. It works without an internet connection.

## Data format
Each record contains:
`record_id, sepal_length, sepal_width, petal_length, petal_width, species, notes, created_at`

Measurements are in centimetres. Species may be `Setosa`, `Versicolor`, `Virginica`, or blank for an unclassified observation. Broad validation bounds are applied to catch implausible entries; they are input safeguards, not a botanical identification standard.

## Demo flow
1. Launch `python main.py`.
2. Choose **1** and enter measurements. Try `abc`, a blank value, or an out-of-range value to demonstrate validation.
3. Leave species blank to explore nearest class-centroid patterns from labelled records.
4. Choose **4** to show totals, averages and class patterns.
5. Choose **5** to create the PNG distribution chart.
6. Choose **6** to export a Markdown summary and audit log.
7. Exit and relaunch; choose **2** to demonstrate persistence.

## Bulk import CSV
Provide a CSV containing at least these headers:
```csv
sepal_length,sepal_width,petal_length,petal_width,species,notes
5.1,3.5,1.4,0.2,Setosa,Sample observation
6.0,2.7,4.5,1.5,Versicolor,Sample observation
```
`species` and `notes` may be omitted or blank. Invalid rows are reported and skipped.

## Project structure
```text
flower_measurement_explorer/
├── main.py
├── flower_explorer/
│   ├── models.py
│   ├── validation.py
│   ├── storage.py
│   ├── analytics.py
│   ├── importer.py
│   ├── exports.py
│   └── cli.py
├── data/
│   ├── flowers.json
│   └── flowers.csv
├── reports/
├── tests/
├── requirements.txt
└── README.md
```
